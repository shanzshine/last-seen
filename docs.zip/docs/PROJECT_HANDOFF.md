# Last Seen — Catatan Diskusi & Handoff Project

Dokumen ini merangkum **perjalanan diskusi kita dari awal** sampai jadi game **Last Seen**, lengkap dengan alasan di balik tiap keputusan desain + ringkasan teknis supaya gampang banget dilanjutin di laptop lain pakai Antigravity.

---

## 1. Awal Mula & Kenapa Pilih Konsep Ini
* **Ide awal:** Pengen bikin game bertahap—mulai dari **web-based dulu**, nanti kalau udah oke pengen dijadiin **mobile app**. Targetnya game yang bikin orang tertarik dan betah main terus.
* **Proses pilih genre:**
  * Sempat bahas game idle/tycoon, roguelite, puzzle harian, merge—tapi belum ada yang klik.
  * Lalu bahas genre party/mabar, detektif/misteri interaktif, PvP, rhythm, & pet breeding ➔ langsung tertarik sama **genre misteri / investigasi interaktif**.
  * Dari 3 sub-konsep (*Investigasi HP/Chat*, *Gatekeeper*, *Interogasi*), langsung jatuh hati sama **Investigasi HP & Chat Misterius (*Phone Forensics*)**!
* **Nama game:** Pengen nama yang **nggak kaku**. Akhirnya sepakat pakai **Last Seen** karena punya makna ganda: status *"last seen"* di chat & istilah kriminal *"terakhir terlihat"*.
* **Arah tema & bahasa:**
  * Fokus tema **kriminal/thriller dulu** (nanti ke depan pengen bikin beberapa versi/tema lain juga, misal horor/drama).
  * Mulai dari **Bahasa Indonesia dulu**, tapi dari awal pengen ada pilihan bahasa (**`ID` / `EN`**) yang beneran **sinkron** antara UI dan isi ceritanya.

---

## 2. Keputusan Desain & Preferensi UI/UX Selama Kita Ngobrol
* **Progres bertahap makin susah & seru:** Setiap nambah kasus harus ada mekanik baru biar makin menantang:
  * **Case #1 (`Kos Nomor 7`):** Fokus pengenalan — Chat, Galeri Foto, & Catatan terkunci PIN 4 digit (`1805`).
  * **Case #2 (`Meja Kerja 02.14`):** Tambah **Maps (Riwayat Lokasi)** & **Pemulihan Chat Terhapus** pakai kata kunci (`HELIOS`).
  * **Case #3 (`Penumpang Terakhir`):** Tambah **Jebakan Chat Live** (pesan ancaman masuk otomatis saat main) & **Analisis Gaya Ketik**.
* **Sistem Hint & Penilaian:**
  * Pakai **Hint bertahap dengan batas maksimal 2 Hint per kasus** (biar pemain nggak asal klik spoiler).
  * Pilih **Rank (`S`, `A`, `B`)** daripada bintang, karena lebih cocok dan serius buat *vibe* game detektif/kriminal. Rank `S` cuma bisa didapat kalau benar semua tanpa pakai Hint & bukti lengkap.
* **Feedback setelah coba buka di HP & Desktop:**
  * **Suasana awal terasa terlalu plain** ➔ ditambah *forensic grid*, *ambient glow*, strip terminal forensik, jam besar di HP, *scanlines*, retakan kaca halus, efek suara (SFX Web Audio API), & *ambient drone* malam hari, plus **Home Web** diperbagus dengan *hero* & *floating preview HP*.
  * **Foto di Galeri kurang realistis** ➔ di-generate 3 foto realistis (`room-key.jpg`, `cafe-receipt.jpg`, `side-gate.jpg`), lalu sempat kena limit kuota *image generator* (reset ~5 jam), jadi **Tiket KAI** dirombak jadi *screenshot E-Boarding Pass* yang realistis.
  * **Foto struk kafe agak kepotong** ➔ ditambah fitur **pop-up perbesar (*lightbox*)** saat foto di Galeri diklik dan pakai `object-contain`.
  * **Buka di HP kurang nyaman & terlalu banyak tombol pakai outline** ➔ layout HP dirapikan biar pas dengan layar mobile (`100dvh`), dan *border/outline* tombol dihilangkan diganti tombol *soft-fill* yang lebih bersih.
* **Progres level berurutan:** Niat awalnya pemain harus namatin Case 1 dulu baru kebuka Case 2, dst. — tapi **sengaja dibiarkan terbuka semua dulu selama masih tahap testing**, baru nanti dikunci saat siap rilis.

---

## 3. Catatan Teknis, Deploy & GitHub
* **Tech Stack:** React + TypeScript + Vite (`base: '/last-seen/'` di `vite.config.ts`), Tailwind CSS v4, Framer Motion, Lucide React, Web Audio API (`src/utils/sound.ts`).
* **Simpan Progres:** Otomatis tersimpan di `localStorage` (`last-seen-save-v1` untuk bukti/PIN/chat terpulihkan/hint/rank, `last-seen-lang` untuk bahasa, `last-seen-muted` untuk audio).
* **Live Link (GitHub Pages):** `https://shanzshine.github.io/last-seen/` (auto-deploy via `.github/workflows/deploy.yml`).
  * *(Catatan: sempat pertimbangkan Vercel, tapi akhirnya pilih coba GitHub Pages dulu; jika nanti pindah ke Vercel, hapus `base: '/last-seen/'` di `vite.config.ts`).*
* **Git Config Lokal:** Pakai `credential.useHttpPath = true`, `user.name = shanzshine`, dan `user.email = shanzshine@users.noreply.github.com` agar tidak mengganggu akun Git lain di laptop dan aman dari blokir privasi email GitHub (`GH007`).

---

## 4. Peta File & Rencana Selanjutnya
* **Data Kasus (ID & EN):** `src/data/case1.ts` & `case1.en.ts`, `case2.ts` & `case2.en.ts`, `case3.ts` & `case3.en.ts`, diatur lewat `src/data/cases.ts`.
* **Komponen HP:** `src/components/PhoneFrame.tsx`, `ChatApp.tsx`, `GalleryApp.tsx`, `NotesApp.tsx`, `MapsApp.tsx`, `PhotoVisual.tsx`, `DeductionModal.tsx`.
* **Next Steps:**
  1. Aktifkan kunci progres berurutan di `src/data/cases.ts` setelah selesai testing.
  2. Buat **Case #4 (`Grup Tanpa Nama`)** sebagai *season finale* konspirasi (*Hidden Vault* & *Multiple Endings*).
  3. Generate sisa foto realistis untuk Galeri Case #2 & #3 ke `public/images/`.
  4. Kembangkan ke **Supabase** (*cloud save* & *daily mini-case*) lalu bungkus jadi **Mobile App** pakai **Capacitor**.
